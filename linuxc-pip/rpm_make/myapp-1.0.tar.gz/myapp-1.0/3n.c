#include "b.h"
#include "c.h"
#include  <stdio.h>

void function3() {
    printf("im fuck fuction3\n");
    printf("im new cast ,sorry\n");
}