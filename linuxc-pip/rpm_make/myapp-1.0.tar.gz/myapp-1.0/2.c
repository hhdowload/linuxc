#include "a.h"
#include "b.h"
#include <stdio.h>


void function2() {
    printf("im fuck fk2\n");
}